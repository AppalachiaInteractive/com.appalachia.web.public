<?php
	header("X-Robots-Tag: noindex, nofollow", true);
	require_once '../../inc/url_set.php';
?>
<script type="text/javascript" src="<?php echo htmlspecialchars(remove_http($_GET['v'])); ?>js/view.core.js"></script>
<div class="hero_viewport">
</div>