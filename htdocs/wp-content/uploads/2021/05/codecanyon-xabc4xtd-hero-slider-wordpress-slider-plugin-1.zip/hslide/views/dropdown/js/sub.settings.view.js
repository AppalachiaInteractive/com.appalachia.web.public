//SUB.SETTINGS VIEW

//view load
jQuery(function(){
	//set header label
	set_current_header_label('Currently Editing', object_name);
});