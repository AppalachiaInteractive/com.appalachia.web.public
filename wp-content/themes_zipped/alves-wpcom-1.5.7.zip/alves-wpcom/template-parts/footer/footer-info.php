<div class="site-info">
	<?php get_template_part( 'template-parts/footer/site', 'name' ); ?>
</div>
