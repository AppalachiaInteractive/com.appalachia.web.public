<h2 class="smoa-tab-title"><i class="sa-icon sa-welcome"></i> Welcome</h2>
<p class="smoa-tab-description">Thank you for purchasing and using the WP Sticky PRO!</p>

<p>If you need help please have a look at our <a target="_blank" href="https://wpsticky.com/documentation/">documentation</a><?php if(!sticky_anything_pro_whitelabel_active()){  ?> or use the support widget that's available in the lower right corner.</p><?php } else { ?>.<?php } ?>


<p>To get started add a new sticky element, give it a nickname and use the visual element picker to set which element on your site will be sticky. That's it :)</p>
