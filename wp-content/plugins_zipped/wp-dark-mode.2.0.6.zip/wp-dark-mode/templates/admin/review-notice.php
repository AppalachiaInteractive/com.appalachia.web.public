<p>Hi there, it seems like <strong>WP Dark Mode</strong> is bringing you some value, and that is pretty awesome!
    Can you please show us some love and rate WP Dark Mode on WordPress? It will take two minutes of your time, and will really help us spread the world.
</p>

<div class="notice-actions">
    <a class="hide_notice" data-value="hide_notice" href="https://wordpress.org/support/plugin/wp-dark-mode/reviews/?filter=5#new-post" target="_blank">I'd love to help :)</a>
    <a href="#" class="remind_later">Not this time</a>
    <a href="#" class="hide_notice" data-value="hide_notice">I've already rated you</a>
</div>

<div class="notice-overlay-wrap">
    <div class="notice-overlay">
        <h4>Would you like us to remind you about this later?</h4>

        <div class="notice-overlay-actions">
            <a href="#" data-value="3">Remind me in 3 days</a>
            <a href="#" data-value="10">Remind me in 10 days</a>
            <a href="#" data-value="hide_notice">Don't remind me about this</a>
        </div>

        <button type="button" class="close-notice">&times;</button>
    </div>
</div>
