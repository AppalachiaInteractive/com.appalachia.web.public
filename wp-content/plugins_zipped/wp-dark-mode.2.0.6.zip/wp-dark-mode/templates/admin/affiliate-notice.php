<p>Hi there, you have been using <strong>WP Dark Mode</strong> for while now. Do you know that <b>WP Dark Mode</b> has an affiliate program?
    join now <b>get 20% commission from each sale.</b>
</p>

<div class="notice-actions">
    <a class="hide_notice button button-primary" data-value="hide_notice" href="https://wppool.dev/affiliates/" target="_blank">
        Tell me more <i class="dashicons dashicons-arrow-right-alt"></i></a>

    <span class="dashicons dashicons-dismiss"></span>

</div>

<div class="notice-overlay-wrap">
    <div class="notice-overlay">
        <h4>Would you like us to remind you about this later?</h4>

        <div class="notice-overlay-actions">
            <a href="#" data-value="3">Remind me in 3 days</a>
            <a href="#" data-value="10">Remind me in 10 days</a>
            <a href="#" data-value="hide_notice">Don't remind me about this</a>
        </div>

        <button type="button" class="close-notice">&times;</button>
    </div>
</div>

<script>
    ;(function ($) {
        $(document).ready(function () {



        });
    })(jQuery);
</script>