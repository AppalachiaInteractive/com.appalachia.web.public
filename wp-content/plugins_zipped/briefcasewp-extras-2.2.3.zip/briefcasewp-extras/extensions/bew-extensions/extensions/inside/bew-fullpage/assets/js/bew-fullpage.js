jQuery( function ( $ ) {

$(document).ready(function() {
    if ($("#fullpage").length > 0 ) {      
        $("#fullpage").addClass("show-bew-fullpage");
    }
 })
 
});