(function( $ ) {
	'use strict';

})( jQuery );
